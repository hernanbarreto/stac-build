#!/usr/bin/env bash
# Frees what Hernán approved on 2026-11-01 ("si, hace lugar"): /workspace/stac-keep, /workspace/stac-validate,
# the May-2026 conda env stac-build, and (01:15) the rejected run copy pccr_audit3; then drops the package-cache entries nothing uses any more and re-measures
# /workspace so the watcher's disk baseline is true again. Low I/O priority: a reconstruction may be running.
set -u
S=/tmp/claude-0/-workspace-stac-build/c7df209a-8a9b-41f3-b8f9-eebbe93f495f/scratchpad
ST=$S/watch_state
CONDA=/workspace/miniforge3/bin/conda
if pgrep -fa "envs/stac-build/" | grep -v shell-snapshots; then echo "ABORT: a process runs from env stac-build"; exit 1; fi
for d in /workspace/stac-keep /workspace/stac-validate /workspace/stac-build/server/projects/pccr_audit3; do
  [ -d "$d" ] || { echo "ya no existe: $d"; continue; }
  echo "borrando $d ($(du -sh "$d" 2>/dev/null | cut -f1))"; ionice -c3 nice -n 19 rm -rf "$d" && echo "  listo"
done
if [ -d /workspace/miniforge3/envs/stac-build ]; then
  echo "borrando env stac-build ($(du -sh /workspace/miniforge3/envs/stac-build 2>/dev/null | cut -f1))"
  ionice -c3 nice -n 19 "$CONDA" env remove -n stac-build -y 2>&1 | tail -n 2
  [ -d /workspace/miniforge3/envs/stac-build ] && ionice -c3 nice -n 19 rm -rf /workspace/miniforge3/envs/stac-build
  echo "  listo"
fi
echo "limpiando la caché de paquetes huérfanos:"; ionice -c3 nice -n 19 "$CONDA" clean --packages --tarballs -y 2>&1 | grep -iE "remove|freed|MB|GB" | tail -n 4
echo "re-midiendo /workspace (tarda unos minutos)…"
tot=$(ionice -c3 nice -n 19 du -sxb /workspace 2>/dev/null | cut -f1)
p=$(ionice -c3 nice -n 19 du -sb /workspace/stac-build/server/projects 2>/dev/null | cut -f1)
r=$(ionice -c3 nice -n 19 du -sb /workspace/stac-build/runs 2>/dev/null | cut -f1)
mkdir -p "$ST"
echo "$tot" > "$ST/workspace_bytes.tmp" && mv "$ST/workspace_bytes.tmp" "$ST/workspace_bytes"; date -u +%s > "$ST/workspace_bytes.t"
echo "$p $r" > "$ST/disk_base"
echo "/workspace ahora: $(( tot / 1000000000 )) GB de 450 (proyectos $(( p / 1000000000 )) GB, runs $(( r / 1000000000 )) GB)"
